export const environment = {
  production: true,
  API_URL: "https://ordeepeorder-dev-web.ap-south-1.elasticbeanstalk.com/api/values/"
};
