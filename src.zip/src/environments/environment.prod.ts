export const environment = {
  production: true,
  API_URL: "http://ordeepeorder-dev-web.ap-south-1.elasticbeanstalk.com/api/values/"
};
