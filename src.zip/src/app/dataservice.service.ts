import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataserviceService {
  serviceData: any;
  adminData: any;
  catagoryList;
}
